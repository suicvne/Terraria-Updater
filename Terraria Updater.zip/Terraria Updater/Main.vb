﻿Imports updatevb

Public Class Main
    Public updater As New updatevb.updatevb

    Private Sub ExitToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ExitToolStripMenuItem.Click

        End

    End Sub

    Private Sub ShowToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ShowToolStripMenuItem.Click

        'When Show menu clicks, it will show the form:

        Me.Show()
        'Me.WindowState = FormWindowState.Normal

        'Show in the task bar:

        Me.ShowInTaskbar = True

        'Disable the Context Menu:

        ContextMenuStrip1.Enabled = False

    End Sub

    Private Sub Form1_FormClosing(ByVal sender As System.Object, ByVal e As System.Windows.Forms.FormClosingEventArgs) Handles MyBase.FormClosing

        'Cancel Closing:

        e.Cancel = True

        'Minimize the form:

        Me.Hide()
        'Me.WindowState = FormWindowState.Minimized

        'Don't show in the task bar

        Me.ShowInTaskbar = False

        'Enable the Context Menu Strip

        ContextMenuStrip1.Enabled = True

    End Sub

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)

        'MsgBox("The application will open a browser window that will download the newest Terraria version", MsgBoxStyle.Information)

        'System.Diagnostics.Process.Start("http://dl.dropbox.com/u/41587981/Terraria.rar")
    End Sub

    Private Sub LinkLabel1_LinkClicked(ByVal sender As System.Object, ByVal e As System.Windows.Forms.LinkLabelLinkClickedEventArgs)

    End Sub

    Private Sub Form1_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        ContextMenuStrip1.Enabled = False
    End Sub

    Private Sub Button4_Click_1(ByVal sender As System.Object, ByVal e As System.EventArgs)
        End
    End Sub

    Private Sub Button6_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button6.Click
        Dim open As New OpenFileDialog
        Dim res As String
        Dim names
        open.ShowDialog()
        open.Filter = "Executable Files(Terraria.exe)|*.exe|All Files(*.*)|*.*"
        names = open.FileName
        If IO.File.Exists(names) Then
            'MsgBox("You have selected:" + names, MsgBoxStyle.Information)
            res = MsgBox("Are you sure this is Terraria? It will launch.", MsgBoxStyle.Question + MsgBoxStyle.YesNo)
            If res = vbYes Then
                System.Diagnostics.Process.Start(names)
            Else
                Exit Sub
            End If
        End If
    End Sub

    Private Sub Button2_Click_1(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button2.Click
        Call LaunchTerraria()
    End Sub

    Private Sub LinkLabel1_LinkClicked_2(ByVal sender As System.Object, ByVal e As System.Windows.Forms.LinkLabelLinkClickedEventArgs) Handles LinkLabel1.LinkClicked
        If Dir("Terraria\") <> "" Then
            System.Diagnostics.Process.Start("Terraria\")
        Else
            'Do nothing
        End If
    End Sub

    Private Sub Button1_Click_1(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        MsgBox("The download will now start. The program may freeze as the Terraria rar is a large file.", MsgBoxStyle.Information)
        If Dir("Terraria\Terraria.rar") <> "" Then
            My.Computer.FileSystem.DeleteFile("Terraria\Terraria.rar")
        End If
        My.Computer.Network.DownloadFile("http://dl.dropbox.com/u/41587981/Terraria.rar", "Terraria\Terraria.rar")

        MsgBox("The download has completed. Please extract files to the Terraria folder. The folder will open now.", MsgBoxStyle.OkOnly)


        System.Diagnostics.Process.Start("Terraria\")
    End Sub

    Private Sub Button5_Click_1(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button5.Click
        Dim oForm As Form2
        oForm = New Form2()
        oForm.Show()
        oForm = Nothing
    End Sub

    Private Sub Button3_Click_1(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button3.Click
        Dim oForm As AboutBox1
        oForm = New AboutBox1()
        oForm.Show()
        oForm = Nothing
    End Sub

    Private Sub ToolStripButton1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ToolStripButton1.Click
        End
    End Sub

    Private Sub Button8_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button8.Click
        MsgBox("This application has an auto update feature in it; Please update through there.")
    End Sub

    Private Sub Button4_Click_2(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button4.Click
        MsgBox("Download Started")
        If Dir("Terraria Mods\TerrariaInvEdit.exe") <> "" Then
            My.Computer.FileSystem.DeleteFile("Terraria Mods\TerrariaInvEdit.exe")
        End If
        My.Computer.Network.DownloadFile("http://dl.dropbox.com/u/41587981/TerrariaInvEdit.exe", "Terraria Mods\TerrariaInvEdit.exe")
        MsgBox("Download Complete")

    End Sub

    Private Sub Button7_Click_1(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button7.Click
        Call InvEdit()
    End Sub
    Private Sub InvEdit()
        If Dir("Terraria Mods\TerrariaInvEdit.exe") <> "" Then
            System.Diagnostics.Process.Start("Terraria Mods\TerrariaInvEdit.exe")
        Else
            MsgBox("The system cannot find the file specified. Download the exe or rename the newest InvEdit exe to TerrariaInvEdit", MsgBoxStyle.Critical)
        End If
    End Sub

    Private Sub Button11_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button11.Click
        MsgBox("This application has an auto update feature in it; Please update through there.")
    End Sub

    Private Sub Button9_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button9.Click
        MsgBox("Download Started")
        If Dir("Terraria Mods\TerrariViewer.exe") <> "" Then
            My.Computer.FileSystem.DeleteFile("TerrariViewer.exe")
        End If
        My.Computer.Network.DownloadFile("http://dl.dropbox.com/u/41587981/TerrariViewer.exe", "Terraria Mods\TerrariViewer.exe")
        MsgBox("Download Complete")
    End Sub

    Private Sub Button10_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button10.Click
        'This checks if the directory exists before launching so there's no random exception statement
        Call TerrariViewer()
    End Sub

    Private Sub ToolStripButton2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ToolStripButton2.Click
        Call CheckforUpdates()
    End Sub

    Private Sub Button12_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button12.Click
        If Dir("Terraria\gMod.rar") <> "" Then
            My.Computer.FileSystem.DeleteFile("Terraria\gMod.rar")
        End If
        My.Computer.Network.DownloadFile("http://dl.dropbox.com/u/41587981/gMod.rar", "Terraria\gMod.rar")
        MsgBox("Download completed. Please use Winrar's extract here function to put all the files into the terraria directory.")
        System.Diagnostics.Process.Start("Terraria Updater\Terraria\")
    End Sub

    Private Sub Button14_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button14.Click
        MsgBox("W.I.P.!")
    End Sub

    Private Sub Button13_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button13.Click
        Call gMod()
    End Sub

    Private Sub LinkLabel2_LinkClicked(ByVal sender As System.Object, ByVal e As System.Windows.Forms.LinkLabelLinkClickedEventArgs) Handles LinkLabel2.LinkClicked
        If Dir("Terraria Mods\") <> "" Then
            System.Diagnostics.Process.Start("Terraria Mods\")
        Else
            'Do nothing...again
        End If
    End Sub

    Private Sub Button15_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button15.Click
        If Dir("Terraria\Content Loader.rar") <> "" Then
            My.Computer.FileSystem.DeleteFile("Terraria\Content Loader.rar")
        End If
        My.Computer.Network.DownloadFile("http://dl.dropbox.com/u/41587981/Content%20Loader.rar", "Terraria\Content Loader.rar")
        MsgBox("Download complete. Please put all of its files right into the Terraria Folder; folder will now open.")
        System.Diagnostics.Process.Start("Terraria\Content Loader.rar")
    End Sub

    Private Sub Button16_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button16.Click
        Call ContentLoader()
    End Sub

    Private Sub Button17_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button17.Click
        MsgBox("Still workin' on a good system for this!")
    End Sub

    Private Sub Button18_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button18.Click
        Dim oForm As ContentHowTo
        oForm = New ContentHowTo()
        oForm.Show()
        oForm = Nothing
    End Sub

    Private Sub ToolStripButton3_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ToolStripButton3.Click
        Dim oForm As TroubleShootingGuide
        oForm = New TroubleShootingGuide()
        oForm.Show()
        oForm = Nothing
    End Sub

    'Code to be called for later in the program

    Private Sub TerrariViewer()
        If Dir("Terraria Mods\TerrariViewer.exe") <> "" Then
            System.Diagnostics.Process.Start("Terraria Mods\TerrariViewer.exe")
        Else
            MsgBox("The system cannot find the file specified. Download the exe or rename to TerrariViewer", MsgBoxStyle.Critical)
        End If
    End Sub

    Private Sub gMod()
        If Dir("Terraria\gMod.exe") <> "" Then
            System.Diagnostics.Process.Start("Terraria\gMod.exe")
        Else
            MsgBox("Couldn't find the file specified. Make sure gMod.exe and all its files are in the Terraria folder", MsgBoxStyle.Critical)
        End If
    End Sub

    Private Sub ContentLoader()
        If Dir("Terraria\TerrariaCustomContentLoader.exe") <> "" Then
            System.Diagnostics.Process.Start("Terraria\TerrariaCustomContentLoader.exe")
        Else
            MsgBox("Program cannot find the file specified; make sure that all the files are where they belong. See troubleshooting for details", MsgBoxStyle.Critical)
        End If
    End Sub

    Private Sub LaunchTerraria()
        If Dir("Terraria\Terraria.exe") <> "" Then
            System.Diagnostics.Process.Start("Terraria\Terraria.exe")
        Else
            MsgBox("System cannot find the file specified. Download Terraria or extract it if already downloaded.", MsgBoxStyle.Critical)
        End If
    End Sub

    Private Sub CheckforUpdates()
        'Used in ToolStripButton2

        updater.checkinternet()
        updater.checkversion("http://dl.dropbox.com/u/41587981/version.txt", "1.2.1")
        If updater.updateavailable = True Then
            If Dir("C:\Temp\changelog.txt") <> "" Then
                My.Computer.FileSystem.DeleteFile("C:\Temp\changelog.txt")
            End If
            My.Computer.Network.DownloadFile("http://dl.dropbox.com/u/41587981/changelog.txt", "C:\Temp\changelog.txt")
            Dim oForm As Update
            oForm = New Update()
            oForm.Show()
            oForm = Nothing

        Else
            MsgBox("You have the latest client version")
        End If
    End Sub

    Private Sub ContextMenuStrip1_Opening(ByVal sender As System.Object, ByVal e As System.ComponentModel.CancelEventArgs) Handles ContextMenuStrip1.Opening

    End Sub

    Private Sub LaunchTerrariaToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles LaunchTerrariaToolStripMenuItem.Click
        Call LaunchTerraria()
    End Sub

    Private Sub TerrariaInvEditToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TerrariaInvEditToolStripMenuItem.Click
        Call InvEdit()
    End Sub

    Private Sub TerrariaViewerToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TerrariaViewerToolStripMenuItem.Click
        Call TerrariViewer()
    End Sub

    Private Sub GModToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles GModToolStripMenuItem.Click
        Call gMod()
    End Sub

    Private Sub ContentLoaderToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ContentLoaderToolStripMenuItem.Click
        Call ContentLoader()
    End Sub

    Private Sub LinkLabel3_LinkClicked(ByVal sender As System.Object, ByVal e As System.Windows.Forms.LinkLabelLinkClickedEventArgs) Handles LinkLabel3.LinkClicked
        System.Diagnostics.Process.Start("http://www.luigifanshack.webs.com")
    End Sub

    Private Sub ToolStripButton4_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ToolStripButton4.Click
        If Dir("C:\Temp\winrar.exe") <> "" Then
            My.Computer.FileSystem.DeleteFile("C:\Temp\winrar.exe")
        End If
        My.Computer.Network.DownloadFile("http://dl.dropbox.com/u/41587981/winrar.exe", "C:\Temp\winrar.exe")
        MsgBox("WinRAR has been successfully downloaded. The installer will now launch")
        System.Diagnostics.Process.Start("C:\Temp\winrar.exe")
    End Sub

    Private Sub Button19_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)
        System.Diagnostics.Process.Start("https://bitbucket.org/Luigifan/terraria-updater/downloads/Terraria%20Updater%20Source%20Code_12.rar")
    End Sub
End Class
