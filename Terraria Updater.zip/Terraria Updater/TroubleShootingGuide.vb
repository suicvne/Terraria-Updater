﻿Public Class TroubleShootingGuide

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        MsgBox("Make sure that ALL of Terraria's files are in <DiskDrive>:\Program Files\Terraria Updater\Terraria")
    End Sub

    Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button2.Click
        MsgBox("Tbh, I probably derped something up; don't worry.")
    End Sub

    Private Sub Button3_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button3.Click
        MsgBox("If you must, message me on Skype: MrMiketheripper")
    End Sub

    Private Sub Button4_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button4.Click
        MsgBox("Soon. Possibly when 1.2 is out, I will release a source edition for you guys to edit and maybe even use it for your own game =x")

        MsgBox("All I ask is that I get some credit")
    End Sub

    Private Sub Button5_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button5.Click
        MsgBox("Maybe some system tray support that'll let you launch Terraria from a system tray icon.")
    End Sub
End Class